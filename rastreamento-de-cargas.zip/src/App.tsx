
import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { ExpeditionView } from './views/ExpeditionView';
import { CentralView } from './views/CentralView';
import { AuditView } from './views/AuditView';
import { AnalysisView } from './views/AnalysisView';
import { LoginView } from './views/LoginView';
import { CargoLoad, CargoStatus, OccurrenceType, User, EventLog, SystemRole } from './types';

type TabType = 'expedition' | 'central' | 'audit' | 'analysis';

// Main Application Component for CargoRelease System - v1.0.1
const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('expedition');
  const [auth, setAuth] = useState<Record<TabType, boolean>>({
    expedition: false,
    central: false,
    audit: false,
    analysis: false,
  });
  const [currentUser, setCurrentUser] = useState<Record<TabType, string | null>>({
    expedition: null,
    central: null,
    audit: null,
    analysis: null,
  });

  const [loads, setLoads] = useState<CargoLoad[]>(() => {
    const saved = localStorage.getItem('cargo_release_loads');
    return saved ? JSON.parse(saved) : [];
  });

  const [users, setUsers] = useState<User[]>(() => {
    const defaultUsers: User[] = [
      { id: '1', username: 'CARGADD', password: '123456', role: 'expedition', systemRole: 'dispatcher', status: 'active', createdAt: new Date().toISOString() },
      { id: '2', username: 'LIBERAÇÃO', password: 'CENTRAL123', role: 'central', systemRole: 'administrator', status: 'active', createdAt: new Date().toISOString() },
      { id: '3', username: 'AUDITORIA', password: 'AUDITOR123', role: 'audit', systemRole: 'auditor', status: 'active', createdAt: new Date().toISOString() },
      { id: '4', username: 'ANALISE', password: 'ANALISE123', role: 'analysis', systemRole: 'administrator', status: 'active', createdAt: new Date().toISOString() },
    ];
    const saved = localStorage.getItem('cargo_release_users');
    if (!saved) return defaultUsers;
    
    const savedUsers: User[] = JSON.parse(saved);
    // Merge default users into saved users if they don't exist
    const merged = [...savedUsers];
    defaultUsers.forEach(defUser => {
      if (!merged.some(u => u.username === defUser.username)) {
        merged.push(defUser);
      }
    });
    return merged;
  });

  const [logs, setLogs] = useState<EventLog[]>(() => {
    const saved = localStorage.getItem('cargo_release_logs');
    return saved ? JSON.parse(saved) : [];
  });

  // Persist data to local storage
  useEffect(() => {
    localStorage.setItem('cargo_release_loads', JSON.stringify(loads));
    localStorage.setItem('cargo_release_users', JSON.stringify(users));
    localStorage.setItem('cargo_release_logs', JSON.stringify(logs));
  }, [loads, users, logs]);

  const addLog = (action: string, details: string, username: string, loadId?: string) => {
    const newLog: EventLog = {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      username,
      action,
      details,
      loadId,
    };
    setLogs(prev => [newLog, ...prev]);
  };

  const handleAddLoad = (newLoadData: Omit<CargoLoad, 'id' | 'status' | 'createdAt' | 'createdBy'>) => {
    const username = currentUser.expedition || 'Sistema';
    const newLoad: CargoLoad = {
      ...newLoadData,
      id: crypto.randomUUID(),
      status: CargoStatus.AWAITING,
      createdAt: new Date().toISOString(),
      createdBy: username,
    };
    setLoads(prev => [newLoad, ...prev]);
    addLog('Criação de Carga', `Carga ${newLoad.plate} criada por ${username}`, username, newLoad.id);
    setActiveTab('central'); 
  };

  const handleUpdateStatus = (id: string, newStatus: CargoStatus) => {
    const load = loads.find(l => l.id === id);
    const username = currentUser.central || 'Sistema';
    setLoads(prev => prev.map(load => 
      load.id === id ? { ...load, status: newStatus } : load
    ));
    if (load) {
      addLog('Atualização de Status', `Carga ${load.plate} alterada para ${newStatus} por ${username}`, username, id);
    }
  };

  const handleUpdateOccurrence = (id: string, type: OccurrenceType, description: string, photo?: string) => {
    const load = loads.find(l => l.id === id);
    const username = currentUser.audit || 'Sistema';
    setLoads(prev => prev.map(load => 
      load.id === id ? { 
        ...load, 
        occurrenceType: type, 
        occurrenceDescription: description,
        occurrencePhoto: photo,
        auditedAt: new Date().toISOString(),
        status: type !== OccurrenceType.NONE ? CargoStatus.BLOCKED : load.status
      } : load
    ));
    if (load) {
      addLog('Auditoria de Carga', `Auditoria realizada na carga ${load.plate} por ${username}. Ocorrência: ${type}`, username, id);
    }
  };

  const handleRegisterUser = (user: Omit<User, 'id' | 'status' | 'createdAt'>) => {
    const newUser: User = {
      ...user,
      id: crypto.randomUUID(),
      status: 'pending',
      systemRole: 'viewer',
      createdAt: new Date().toISOString(),
    };
    setUsers(prev => [...prev, newUser]);
    addLog('Solicitação de Cadastro', `Novo usuário ${newUser.username} (${newUser.fullName || 'S/N'}) - Loja: ${newUser.storeLocation || 'S/N'} aguardando aprovação`, 'Sistema');
  };

  const handleApproveUser = (userId: string, approve: boolean) => {
    const user = users.find(u => u.id === userId);
    const username = currentUser.audit || 'Sistema';
    setUsers(prev => prev.map(u => 
      u.id === userId ? { ...u, status: approve ? 'active' : 'rejected' } : u
    ));
    if (user) {
      addLog('Gestão de Usuários', `Usuário ${user.username} ${approve ? 'aprovado' : 'rejeitado'} por ${username}`, username);
    }
  };

  const handleDeleteUser = (userId: string) => {
    const user = users.find(u => u.id === userId);
    const username = currentUser.audit || 'Sistema';
    setUsers(prev => prev.filter(u => u.id !== userId));
    if (user) {
      addLog('Gestão de Usuários', `Usuário ${user.username} excluído por ${username}`, username);
    }
  };

  const handleChangePassword = (userId: string, newPassword: string) => {
    const user = users.find(u => u.id === userId);
    const username = currentUser.audit || 'Sistema';
    setUsers(prev => prev.map(u => 
      u.id === userId ? { ...u, password: newPassword } : u
    ));
    if (user) {
      addLog('Gestão de Usuários', `Senha do usuário ${user.username} alterada por ${username}`, username);
    }
  };

  const handleUpdateSystemRole = (userId: string, systemRole: SystemRole) => {
    const user = users.find(u => u.id === userId);
    const username = currentUser.audit || 'Sistema';
    setUsers(prev => prev.map(u => 
      u.id === userId ? { ...u, systemRole } : u
    ));
    if (user) {
      addLog('Gestão de Usuários', `Perfil de sistema do usuário ${user.username} alterado para ${systemRole} por ${username}`, username);
    }
  };

  const handleLoginSuccess = (tab: TabType, username: string) => {
    setAuth(prev => ({ ...prev, [tab]: true }));
    setCurrentUser(prev => ({ ...prev, [tab]: username }));
    addLog('Login', `Usuário ${username} acessou a etapa ${tab}`, username);
  };

  const handleLogout = (tab: TabType) => {
    const username = currentUser[tab] || 'Desconhecido';
    setAuth(prev => ({ ...prev, [tab]: false }));
    setCurrentUser(prev => ({ ...prev, [tab]: null }));
    addLog('Logout', `Usuário ${username} saiu da etapa ${tab}`, username);
  };

  const renderContent = () => {
    if (!auth[activeTab]) {
      return (
        <LoginView 
          role={activeTab} 
          users={users}
          onLoginSuccess={(username) => handleLoginSuccess(activeTab, username)} 
          onRegisterRequest={handleRegisterUser}
        />
      );
    }

    switch (activeTab) {
      case 'expedition':
        return <ExpeditionView onSubmit={handleAddLoad} logs={logs.filter(l => l.username === currentUser.expedition)} />;
      case 'central':
        return <CentralView loads={loads} onUpdateStatus={handleUpdateStatus} />;
      case 'audit':
        return (
          <AuditView 
            loads={loads} 
            users={users}
            logs={logs}
            onUpdateOccurrence={handleUpdateOccurrence} 
            onApproveUser={handleApproveUser}
            onDeleteUser={handleDeleteUser}
            onChangePassword={handleChangePassword}
            onUpdateSystemRole={handleUpdateSystemRole}
          />
        );
      case 'analysis':
        return <AnalysisView loads={loads} />;
      default:
        return null;
    }
  };

  return (
    <Layout 
      activeTab={activeTab} 
      onTabChange={setActiveTab} 
      onLogout={handleLogout}
      isAuthenticated={auth[activeTab]}
    >
      <div className="animate-in fade-in duration-500">
        {renderContent()}
      </div>
    </Layout>
  );
};

export default App;
