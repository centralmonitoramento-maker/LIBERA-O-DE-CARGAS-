
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: 'expedition' | 'central' | 'audit' | 'analysis';
  onTabChange: (tab: 'expedition' | 'central' | 'audit' | 'analysis') => void;
  onLogout: (tab: 'expedition' | 'central' | 'audit' | 'analysis') => void;
  isAuthenticated: boolean;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange, onLogout, isAuthenticated }) => {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-slate-900 text-white shadow-lg">
        <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-xl">CR</div>
            <h1 className="text-xl font-bold tracking-tight">CargoRelease <span className="text-blue-400">System</span></h1>
          </div>
          <div className="flex items-center gap-4">
            <nav className="flex gap-1 bg-slate-800 p-1 rounded-lg overflow-x-auto max-w-full">
              <button
                onClick={() => onTabChange('expedition')}
                className={`px-4 py-2 rounded-md transition-all text-sm font-medium whitespace-nowrap ${
                  activeTab === 'expedition' 
                    ? 'bg-blue-600 text-white shadow-sm' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                1. Expedição
              </button>
              <button
                onClick={() => onTabChange('central')}
                className={`px-4 py-2 rounded-md transition-all text-sm font-medium whitespace-nowrap ${
                  activeTab === 'central' 
                    ? 'bg-blue-600 text-white shadow-sm' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                2. Central
              </button>
              <button
                onClick={() => onTabChange('audit')}
                className={`px-4 py-2 rounded-md transition-all text-sm font-medium whitespace-nowrap ${
                  activeTab === 'audit' 
                    ? 'bg-blue-600 text-white shadow-sm' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                3. Auditoria
              </button>
              <button
                onClick={() => onTabChange('analysis')}
                className={`px-4 py-2 rounded-md transition-all text-sm font-medium whitespace-nowrap ${
                  activeTab === 'analysis' 
                    ? 'bg-blue-600 text-white shadow-sm' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                4. Análise
              </button>
            </nav>
            {isAuthenticated && (
              <button
                onClick={() => onLogout(activeTab)}
                className="p-2 text-slate-400 hover:text-red-400 transition-colors"
                title="Sair desta etapa"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
              </button>
            )}
          </div>
        </div>
      </header>
      <main className="flex-1 container mx-auto px-4 py-8">
        {children}
      </main>
      <footer className="bg-slate-100 border-t border-slate-200 py-6 text-center text-slate-500 text-xs">
        &copy; {new Date().getFullYear()} CargoRelease System - Logística de Alta Precisão
      </footer>
    </div>
  );
};
