
export enum CargoStatus {
  AWAITING = 'AGUARDANDO CONFERÊNCIA',
  RELEASED = 'CARGA LIBERADA',
  BLOCKED = 'CARGA BLOQUEADA'
}

export enum CargoType {
  FLV = 'FLV (Frutas, Legumes, Verduras)',
  MISTA = 'Mista',
  SECA = 'Seca',
  TRANSFERENCIA = 'Transferência',
  COMPARTILHADA = 'Carga Compartilhada'
}

export enum OccurrenceType {
  NONE = 'Nenhuma',
  SEAL_DISCREPANCY = 'Divergência de Lacre',
  CARGO_EXCHANGE = 'Troca de Cargas',
  SEAL_TAMPERED = 'Lacre Rompido/Trocado',
  QUANTITY_DISCREPANCY = 'Divergência de Quantidade',
  OTHER = 'Outros'
}

export interface CargoLoad {
  id: string;
  plate: string;
  driverName: string;
  cargoType: CargoType;
  origin: string;
  destination: string;
  additionalDestinations?: string[];
  isHighRisk: boolean;
  parType?: string;
  parInvoiceNumber?: string;
  parDescription?: string;
  sealNumber: string;
  palletCount: number;
  palletDetails?: {
    type: string;
    quantity: number;
  }[];
  status: CargoStatus;
  createdAt: string;
  createdBy: string; // Username of the expedition user
  occurrenceType?: OccurrenceType;
  occurrenceDescription?: string;
  occurrencePhoto?: string;
  auditedAt?: string;
}

export type SystemRole = 'administrator' | 'dispatcher' | 'auditor' | 'viewer';

export interface User {
  id: string;
  username: string;
  password: string;
  fullName?: string;
  storeLocation?: string;
  jobFunction?: string;
  role: 'expedition' | 'central' | 'audit' | 'analysis';
  systemRole?: SystemRole;
  status: 'pending' | 'active' | 'rejected';
  createdAt: string;
}

export interface EventLog {
  id: string;
  timestamp: string;
  userId?: string;
  username: string;
  action: string;
  details: string;
  loadId?: string;
}

export interface VerificationResult {
  isMatch: boolean;
  message: string;
}
