
import React, { useMemo, useState } from 'react';
import { CargoLoad, OccurrenceType } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend, LineChart, Line, AreaChart, Area
} from 'recharts';
import { 
  TrendingUp, AlertTriangle, MapPin, BarChart3, 
  PieChart as PieChartIcon, Activity, ArrowUpRight, ArrowDownRight,
  Search, X, Filter
} from 'lucide-react';

interface AnalysisViewProps {
  loads: CargoLoad[];
}

const COLORS = ['#3b82f6', '#ef4444', '#f59e0b', '#10b981', '#8b5cf6', '#6366f1', '#ec4899'];

export const AnalysisView: React.FC<AnalysisViewProps> = ({ loads }) => {
  const [selectedCategory, setSelectedCategory] = useState<{ type: 'occurrence' | 'route' | null; value: string | null }>({ type: null, value: null });
  
  // Date filters
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // Filter loads based on date range
  const filteredLoadsByDate = useMemo(() => {
    if (!startDate && !endDate) return loads;
    
    return loads.filter(load => {
      const loadDate = new Date(load.auditedAt || load.createdAt).getTime();
      const start = startDate ? new Date(startDate).getTime() : -Infinity;
      const end = endDate ? new Date(endDate).getTime() : Infinity;
      
      return loadDate >= start && loadDate <= end;
    });
  }, [loads, startDate, endDate]);

  // Process data for charts
  const stats = useMemo(() => {
    const occurrenceCounts: Record<string, number> = {};
    const routeStats: Record<string, { totalOccurrences: number; totalLoads: number; [key: string]: number }> = {};
    const dailyOccurrences: Record<string, number> = {};
    const allOccurrenceTypes = new Set<string>();
    
    let totalOccurrences = 0;
    
    filteredLoadsByDate.forEach(load => {
      const route = `${load.origin} ➔ ${load.destination}`;
      if (!routeStats[route]) {
        routeStats[route] = { totalOccurrences: 0, totalLoads: 0 };
      }
      routeStats[route].totalLoads++;

      if (load.occurrenceType && load.occurrenceType !== OccurrenceType.NONE) {
        totalOccurrences++;
        
        // Count by type
        occurrenceCounts[load.occurrenceType] = (occurrenceCounts[load.occurrenceType] || 0) + 1;
        allOccurrenceTypes.add(load.occurrenceType);
        
        // Count by route
        routeStats[route].totalOccurrences++;
        routeStats[route][load.occurrenceType] = (routeStats[route][load.occurrenceType] || 0) + 1;
        
        // Count by date
        if (load.auditedAt) {
          const date = new Date(load.auditedAt).toLocaleDateString('pt-BR');
          dailyOccurrences[date] = (dailyOccurrences[date] || 0) + 1;
        }
      }
    });

    const occurrenceData = Object.entries(occurrenceCounts).map(([name, value]) => ({ name, value }));
    const routeData = Object.entries(routeStats)
      .map(([name, data]) => ({ 
        name, 
        ...data,
        rate: data.totalLoads > 0 ? Number(((data.totalOccurrences / data.totalLoads) * 100).toFixed(1)) : 0
      }))
      .sort((a, b) => b.totalOccurrences - a.totalOccurrences)
      .slice(0, 5);
      
    const timelineData = Object.entries(dailyOccurrences)
      .map(([date, count]) => ({ date, count }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    return {
      totalOccurrences,
      occurrenceData,
      routeData,
      timelineData,
      allOccurrenceTypes: Array.from(allOccurrenceTypes),
      totalLoads: filteredLoadsByDate.length,
      occurrenceRate: filteredLoadsByDate.length > 0 ? ((totalOccurrences / filteredLoadsByDate.length) * 100).toFixed(1) : '0'
    };
  }, [filteredLoadsByDate]);

  const filteredLoads = useMemo(() => {
    if (!selectedCategory.type || !selectedCategory.value) return [];
    
    return filteredLoadsByDate.filter(load => {
      if (selectedCategory.type === 'occurrence') {
        return load.occurrenceType === selectedCategory.value;
      } else {
        const route = `${load.origin} ➔ ${load.destination}`;
        return route === selectedCategory.value && load.occurrenceType && load.occurrenceType !== OccurrenceType.NONE;
      }
    }).slice(0, 10); // Show only top 10 recent
  }, [filteredLoadsByDate, selectedCategory]);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
            <BarChart3 className="text-blue-600" />
            Dashboard de Análise
          </h2>
          <p className="text-slate-500 font-medium">Visão analítica de ocorrências, rotas e performance de auditoria.</p>
        </div>
        
        {/* Date Filters */}
        <div className="flex flex-wrap items-center gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm w-full lg:w-auto">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <span className="text-xs font-black text-slate-500 uppercase tracking-wider">Filtros:</span>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 flex-1 lg:flex-none">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Início</label>
              <input 
                type="datetime-local" 
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="text-xs font-bold text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Fim</label>
              <input 
                type="datetime-local" 
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="text-xs font-bold text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
            </div>
          </div>
          {(startDate || endDate) && (
            <button 
              onClick={() => { setStartDate(''); setEndDate(''); }}
              className="mt-5 p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg transition-colors"
              title="Limpar Filtros"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Activity className="w-6 h-6 text-blue-600" />
            </div>
            <span className="flex items-center text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">
              <ArrowUpRight className="w-3 h-3" /> +12%
            </span>
          </div>
          <h3 className="text-slate-500 text-xs font-black uppercase tracking-wider mb-1">Total de Cargas</h3>
          <p className="text-3xl font-black text-slate-800">{stats.totalLoads}</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-red-100 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <span className="flex items-center text-[10px] font-bold text-red-600 bg-red-50 px-2 py-1 rounded-full">
              <ArrowUpRight className="w-3 h-3" /> +5%
            </span>
          </div>
          <h3 className="text-slate-500 text-xs font-black uppercase tracking-wider mb-1">Total de Ocorrências</h3>
          <p className="text-3xl font-black text-slate-800">{stats.totalOccurrences}</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-amber-100 rounded-lg">
              <TrendingUp className="w-6 h-6 text-amber-600" />
            </div>
            <span className="flex items-center text-[10px] font-bold text-red-600 bg-red-50 px-2 py-1 rounded-full">
              <ArrowUpRight className="w-3 h-3" /> +2.1%
            </span>
          </div>
          <h3 className="text-slate-500 text-xs font-black uppercase tracking-wider mb-1">Taxa de Ocorrência</h3>
          <p className="text-3xl font-black text-slate-800">{stats.occurrenceRate}%</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <MapPin className="w-6 h-6 text-emerald-600" />
            </div>
            <span className="flex items-center text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">
              Estável
            </span>
          </div>
          <h3 className="text-slate-500 text-xs font-black uppercase tracking-wider mb-1">Rotas Ativas</h3>
          <p className="text-3xl font-black text-slate-800">{Object.keys(stats.routeData).length}</p>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Occurrence Types */}
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-50 rounded-xl">
                <PieChartIcon className="w-5 h-5 text-blue-600" />
              </div>
              <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">Tipos de Ocorrência</h3>
            </div>
            <p className="text-[10px] font-bold text-slate-400 uppercase">Clique para detalhar</p>
          </div>
          <div className="h-[350px] w-full">
            {stats.occurrenceData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats.occurrenceData}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={120}
                    paddingAngle={5}
                    dataKey="value"
                    onClick={(data) => setSelectedCategory({ type: 'occurrence', value: data.name })}
                    className="cursor-pointer"
                  >
                    {stats.occurrenceData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={COLORS[index % COLORS.length]} 
                        stroke={selectedCategory.value === entry.name ? '#000' : 'none'}
                        strokeWidth={2}
                      />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    formatter={(value: number) => {
                      const percent = ((value / stats.totalOccurrences) * 100).toFixed(1);
                      return [`${value} (${percent}%)`, 'Ocorrências'];
                    }}
                  />
                  <Legend verticalAlign="bottom" height={36}/>
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 italic">
                Sem dados de ocorrência para exibir.
              </div>
            )}
          </div>
        </div>

        {/* Top Routes with Occurrences */}
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-50 rounded-xl">
                <MapPin className="w-5 h-5 text-red-600" />
              </div>
              <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">Rotas com Maiores Ocorrências</h3>
            </div>
            <p className="text-[10px] font-bold text-slate-400 uppercase">Clique para detalhar</p>
          </div>
          <div className="h-[350px] w-full">
            {stats.routeData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.routeData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f1f5f9" />
                  <XAxis type="number" hide />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    width={150} 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 10, fontWeight: 700, fill: '#64748b' }}
                  />
                  <Tooltip 
                    cursor={{ fill: '#f8fafc' }}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    formatter={(value: any, name: string) => {
                      if (name === 'rate') return [`${value}%`, 'Taxa de Ocorrência'];
                      if (name === 'totalLoads') return [value, 'Total de Cargas'];
                      if (name === 'totalOccurrences') return [value, 'Total de Ocorrências'];
                      return [value, name];
                    }}
                  />
                  <Legend verticalAlign="top" height={36} iconType="circle" wrapperStyle={{ fontSize: '10px', fontWeight: 700 }} />
                  {stats.allOccurrenceTypes.map((type, index) => (
                    <Bar 
                      key={type} 
                      dataKey={type} 
                      name={type}
                      stackId="a" 
                      fill={COLORS[index % COLORS.length]} 
                      barSize={24}
                      onClick={(data) => setSelectedCategory({ type: 'route', value: data.name })}
                      className="cursor-pointer"
                    />
                  ))}
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 italic">
                Sem dados de rotas para exibir.
              </div>
            )}
          </div>
        </div>

        {/* Category Details (Drill-down) */}
        {selectedCategory.value && (
          <div className="lg:col-span-2 bg-slate-900 text-white p-8 rounded-3xl shadow-xl animate-in zoom-in-95 duration-300">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/10 rounded-xl">
                  <Filter className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h3 className="text-lg font-black uppercase tracking-tight">Detalhes: {selectedCategory.value}</h3>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Exploração de dados específicos</p>
                </div>
              </div>
              <button 
                onClick={() => setSelectedCategory({ type: null, value: null })}
                className="p-2 hover:bg-white/10 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              {filteredLoads.map((load) => (
                <div key={load.id} className="bg-white/5 border border-white/10 p-4 rounded-2xl hover:bg-white/10 transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] font-black bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded-full uppercase">
                      Carga #{load.id.slice(-4)}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{new Date(load.auditedAt || '').toLocaleString('pt-BR')}</span>
                  </div>
                  <p className="text-sm font-bold mb-1">{load.origin} ➔ {load.destination}</p>
                  <p className="text-xs text-slate-400 line-clamp-1 italic">"{load.occurrenceDescription || 'Sem descrição'}"</p>
                </div>
              ))}
              {filteredLoads.length === 0 && (
                <p className="text-slate-500 italic text-sm col-span-2 text-center py-8">Nenhuma carga recente encontrada para este filtro.</p>
              )}
            </div>
            
            <div className="flex justify-center">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Mostrando as 10 ocorrências mais recentes</p>
            </div>
          </div>
        )}

        {/* Timeline of Occurrences */}
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm lg:col-span-2">
          <div className="flex items-center gap-3 mb-8">
            <div className="p-2 bg-emerald-50 rounded-xl">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
            </div>
            <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">Evolução Temporal de Ocorrências</h3>
          </div>
          <div className="h-[300px] w-full">
            {stats.timelineData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={stats.timelineData}>
                  <defs>
                    <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="date" 
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fontSize: 10, fontWeight: 600, fill: '#94a3b8' }}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 10, fontWeight: 600, fill: '#94a3b8' }}
                  />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="count" 
                    stroke="#10b981" 
                    strokeWidth={3}
                    fillOpacity={1} 
                    fill="url(#colorCount)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 italic">
                Sem dados temporais suficientes.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
