
import React, { useState, useRef } from 'react';
import { CargoLoad, OccurrenceType, CargoStatus, User, EventLog, SystemRole } from '../types';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface AuditViewProps {
  loads: CargoLoad[];
  users: User[];
  logs: EventLog[];
  onUpdateOccurrence: (id: string, type: OccurrenceType, description: string, photo?: string) => void;
  onApproveUser: (userId: string, approve: boolean) => void;
  onDeleteUser: (userId: string) => void;
  onChangePassword: (userId: string, newPassword: string) => void;
  onUpdateSystemRole: (userId: string, systemRole: SystemRole) => void;
}

export const AuditView: React.FC<AuditViewProps> = ({ 
  loads, 
  users, 
  logs, 
  onUpdateOccurrence, 
  onApproveUser,
  onDeleteUser,
  onChangePassword,
  onUpdateSystemRole
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'audit' | 'users' | 'logs'>('audit');
  const [selectedLoadId, setSelectedLoadId] = useState<string | null>(null);
  const [occType, setOccType] = useState<OccurrenceType>(OccurrenceType.NONE);
  const [occDescription, setOccDescription] = useState('');
  const [occPhoto, setOccPhoto] = useState<string | undefined>(undefined);
  const [sealInput, setSealInput] = useState('');
  const [saveFeedback, setSaveFeedback] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedLoad = loads.find(l => l.id === selectedLoadId);

  const handleSaveOccurrence = () => {
    if (selectedLoad) {
      // Basic validation: if occurrence is selected, seal input must not be empty
      if (occType !== OccurrenceType.NONE && !sealInput) {
        alert('Por favor, confirme o número do lacre antes de salvar.');
        return;
      }

      // Description validation for specific types
      const requiresDescription = [
        OccurrenceType.SEAL_DISCREPANCY,
        OccurrenceType.CARGO_EXCHANGE,
        OccurrenceType.SEAL_TAMPERED
      ].includes(occType);

      if (requiresDescription && !occDescription.trim()) {
        alert('Para este tipo de ocorrência, a descrição detalhada é obrigatória.');
        return;
      }

      // If it's a normal occurrence (not seal related), it must match the original seal
      if (occType !== OccurrenceType.NONE && 
          occType !== OccurrenceType.SEAL_DISCREPANCY && 
          occType !== OccurrenceType.SEAL_TAMPERED && 
          sealInput !== selectedLoad.sealNumber) {
        alert('O lacre digitado não confere com o manifesto. Verifique os dados ou selecione "Divergência de Lacre".');
        return;
      }

      onUpdateOccurrence(selectedLoad.id, occType, occDescription, occPhoto);
      setSaveFeedback(true);
      setTimeout(() => setSaveFeedback(false), 3000);
    }
  };

  const handleSelectLoad = (id: string) => {
    const load = loads.find(l => l.id === id);
    setSelectedLoadId(id);
    if (load) {
      setOccType(load.occurrenceType || OccurrenceType.NONE);
      setOccDescription(load.occurrenceDescription || '');
      setOccPhoto(load.occurrencePhoto);
      setSealInput('');
    }
    setSaveFeedback(false);
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setOccPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removePhoto = () => {
    setOccPhoto(undefined);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const pendingUsers = users.filter(u => u.status === 'pending');

  const exportToPDF = () => {
    const doc = new jsPDF();
    
    // Header
    doc.setFontSize(18);
    doc.text('Event Log Report - CargoRelease', 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);
    doc.text(`Generated on: ${new Date().toLocaleString('pt-BR')}`, 14, 30);
    
    // Table
    const tableData = logs.map(log => [
      new Date(log.timestamp).toLocaleString('pt-BR'),
      log.username,
      log.action,
      log.details
    ]);

    autoTable(doc, {
      startY: 35,
      head: [['Timestamp', 'Username', 'Action', 'Details']],
      body: tableData,
      theme: 'striped',
      headStyles: { fillColor: [15, 23, 42] }, // slate-900
      styles: { fontSize: 8, cellPadding: 3, overflow: 'linebreak' },
      columnStyles: {
        0: { cellWidth: 35 },
        1: { cellWidth: 30 },
        2: { cellWidth: 40 },
        3: { cellWidth: 'auto' }
      }
    });

    doc.save(`event-logs-${new Date().toISOString().split('T')[0]}.pdf`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-end gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-800 tracking-tight">Etapa 3: Auditoria & Gestão</h2>
          <p className="text-slate-500 font-medium">Controle de gate, gestão de usuários e log de eventos do sistema.</p>
        </div>
        <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
          <button 
            onClick={() => setActiveSubTab('audit')}
            className={`px-4 py-2 rounded-lg text-xs font-black transition-all ${activeSubTab === 'audit' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            AUDITORIA
          </button>
          <button 
            onClick={() => setActiveSubTab('users')}
            className={`px-4 py-2 rounded-lg text-xs font-black transition-all flex items-center gap-2 ${activeSubTab === 'users' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            USUÁRIOS
            {pendingUsers.length > 0 && <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>}
          </button>
          <button 
            onClick={() => setActiveSubTab('logs')}
            className={`px-4 py-2 rounded-lg text-xs font-black transition-all ${activeSubTab === 'logs' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            LOGS
          </button>
        </div>
      </div>

      {activeSubTab === 'audit' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-in fade-in duration-300">
          {/* List of released loads for audit */}
          <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col h-[750px]">
            <div className="p-5 border-b bg-slate-50/50 rounded-t-2xl">
              <h3 className="font-bold text-slate-700">Histórico de Cargas</h3>
            </div>
            <div className="overflow-y-auto flex-1 p-3 space-y-3">
              {loads.length === 0 ? (
                <div className="h-full flex items-center justify-center text-slate-400 italic">Sem registros no sistema.</div>
              ) : (
                loads.map((load) => (
                  <button
                    key={load.id}
                    onClick={() => handleSelectLoad(load.id)}
                    className={`w-full text-left p-4 rounded-xl border transition-all ${
                      selectedLoadId === load.id 
                        ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-50' 
                        : 'border-slate-100 hover:border-slate-200'
                    }`}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-mono font-black text-slate-800">{load.plate}</span>
                      <div className="flex gap-1">
                        {load.auditedAt && (
                          <span className="text-[9px] px-2 py-0.5 rounded-full font-bold bg-blue-100 text-blue-700">
                            AUDITADO
                          </span>
                        )}
                        <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${
                          load.status === CargoStatus.RELEASED ? 'bg-emerald-100 text-emerald-700' : 
                          load.status === CargoStatus.BLOCKED ? 'bg-red-100 text-red-700' :
                          'bg-slate-100 text-slate-500'
                        }`}>
                          {load.status}
                        </span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-slate-500 font-medium truncate w-32">{load.driverName}</span>
                      {(load.occurrenceType && load.occurrenceType !== OccurrenceType.NONE) || load.occurrencePhoto ? (
                        <span className="text-[9px] text-red-600 font-bold flex items-center gap-1">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd"></path></svg>
                          Ocorrência
                        </span>
                      ) : null}
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Audit Form */}
          <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
            {selectedLoad ? (
              <div className="p-8 space-y-8 overflow-y-auto">
                <div className="flex justify-between items-start border-b pb-6">
                  <div>
                    <h3 className="text-2xl font-black text-slate-800">{selectedLoad.plate}</h3>
                    <p className="text-sm text-slate-500">Manifesto: {selectedLoad.id.slice(0, 8).toUpperCase()}</p>
                    <p className="text-[10px] text-slate-400 font-bold mt-1">Criado por: {selectedLoad.createdBy}</p>
                    {selectedLoad.auditedAt && (
                      <p className="text-[10px] text-emerald-600 font-bold mt-1 flex items-center gap-1">
                        <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>
                        AUDITADO EM: {new Date(selectedLoad.auditedAt).toLocaleString('pt-BR')}
                      </p>
                    )}
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-black text-slate-400 uppercase">Lacre Original</p>
                    <p className="text-lg font-mono font-black text-blue-600">{selectedLoad.sealNumber}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                    <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Origem</p>
                    <p className="text-sm font-bold text-slate-700">{selectedLoad.origin}</p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                    <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Destino Principal</p>
                    <p className="text-sm font-bold text-slate-700">{selectedLoad.destination}</p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                    <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Carga</p>
                    <p className="text-sm font-bold text-slate-700">{selectedLoad.cargoType}</p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                    <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Volume (Paletes)</p>
                    <div className="flex flex-col">
                      <p className="text-sm font-bold text-slate-700">{selectedLoad.palletCount} un</p>
                      {selectedLoad.palletDetails && selectedLoad.palletDetails.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {selectedLoad.palletDetails.map((p, i) => (
                            <span key={i} className="text-[8px] bg-white text-slate-500 px-1 py-0.5 rounded border border-slate-200 font-black uppercase">
                              {p.quantity}x {p.type}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {selectedLoad.isHighRisk && (
                  <div className="p-4 bg-red-50 border border-red-100 rounded-xl space-y-3">
                    <div className="flex gap-3">
                      <div className="text-red-500 mt-0.5">
                        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd"></path></svg>
                      </div>
                      <div>
                        <p className="text-[10px] font-black text-red-700 uppercase tracking-widest">Alerta de Carga PAR</p>
                        <div className="mt-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <p className="text-[9px] font-bold text-red-400 uppercase">Item PAR</p>
                            <p className="text-xs font-bold text-red-900">{selectedLoad.parType}</p>
                          </div>
                          <div>
                            <p className="text-[9px] font-bold text-red-400 uppercase">Nota Fiscal</p>
                            <p className="text-xs font-bold text-red-900">{selectedLoad.parInvoiceNumber}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    {selectedLoad.parDescription && (
                      <div className="pt-2 border-t border-red-200/50">
                        <p className="text-[9px] font-bold text-red-400 uppercase">Observações Adicionais</p>
                        <p className="text-xs font-medium text-red-900 leading-snug">{selectedLoad.parDescription}</p>
                      </div>
                    )}
                  </div>
                )}

                <div className="space-y-6">
                  <div className="p-6 bg-slate-900 rounded-2xl text-white">
                    <h4 className="font-bold text-blue-400 mb-6 flex items-center gap-2">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                      Registro de Ocorrências
                    </h4>
                    
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-4">
                          <div>
                            <label className="text-[10px] font-black text-slate-400 uppercase mb-2 block">Tipo de Ocorrência</label>
                            <select 
                              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none"
                              value={occType}
                              onChange={(e) => setOccType(e.target.value as OccurrenceType)}
                            >
                              {Object.values(OccurrenceType).map(type => (
                                <option key={type} value={type}>{type}</option>
                              ))}
                            </select>
                          </div>

                          {occType !== OccurrenceType.NONE && (
                            <div className="animate-in slide-in-from-top-2 duration-300">
                              <label className="text-[10px] font-black text-slate-400 uppercase mb-2 block">
                                Confirmação de Lacre (Digite o Lacre Encontrado)
                              </label>
                              <div className="relative">
                                <input 
                                  type="text"
                                  className={`w-full bg-slate-800 border rounded-xl px-4 py-3 text-sm font-mono font-bold outline-none transition-all ${
                                    sealInput === '' 
                                      ? 'border-slate-700' 
                                      : (sealInput === selectedLoad.sealNumber 
                                          ? 'border-emerald-500 ring-1 ring-emerald-500' 
                                          : 'border-red-500 ring-1 ring-red-500')
                                  }`}
                                  placeholder="Digite o número do lacre..."
                                  value={sealInput}
                                  onChange={(e) => setSealInput(e.target.value.toUpperCase())}
                                />
                                {sealInput !== '' && (
                                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                                    {sealInput === selectedLoad.sealNumber ? (
                                      <svg className="w-5 h-5 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>
                                    ) : (
                                      <svg className="w-5 h-5 text-red-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd"></path></svg>
                                    )}
                                  </div>
                                )}
                              </div>
                              <p className={`text-[9px] font-bold mt-1 uppercase tracking-tight ${
                                sealInput === '' ? 'text-slate-500' : (sealInput === selectedLoad.sealNumber ? 'text-emerald-400' : 'text-red-400')
                              }`}>
                                {sealInput === '' 
                                  ? 'Aguardando digitação...' 
                                  : (sealInput === selectedLoad.sealNumber 
                                      ? 'Lacre conferido com sucesso!' 
                                      : (occType === OccurrenceType.SEAL_DISCREPANCY || occType === OccurrenceType.SEAL_TAMPERED 
                                          ? 'Divergência confirmada (prossiga com o registro)' 
                                          : 'Atenção: Lacre não confere com o manifesto!'))}
                              </p>
                            </div>
                          )}

                          <div>
                            <label className="text-[10px] font-black text-slate-400 uppercase mb-2 block">Evidência Fotográfica</label>
                            <div className="flex flex-col gap-3">
                              <input 
                                type="file" 
                                accept="image/*" 
                                capture="environment" 
                                className="hidden" 
                                ref={fileInputRef}
                                onChange={handlePhotoChange}
                              />
                              <button 
                                onClick={() => fileInputRef.current?.click()}
                                className="w-full bg-slate-800 border-2 border-dashed border-slate-700 hover:border-blue-500 hover:bg-slate-700 p-4 rounded-xl flex flex-col items-center justify-center gap-2 transition-all group"
                              >
                                <svg className="w-6 h-6 text-slate-500 group-hover:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                                <span className="text-[10px] font-bold text-slate-400 group-hover:text-blue-300">ANEXAR OU TIRAR FOTO</span>
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-center bg-slate-800 rounded-xl border border-slate-700 min-h-[200px] relative overflow-hidden">
                          {occPhoto ? (
                            <>
                              <img src={occPhoto} alt="Evidência" className="w-full h-full object-cover" />
                              <button 
                                onClick={removePhoto}
                                className="absolute top-2 right-2 bg-red-600/80 hover:bg-red-600 p-1.5 rounded-full text-white shadow-lg transition-all"
                                title="Remover Foto"
                              >
                                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd"></path></svg>
                              </button>
                            </>
                          ) : (
                            <span className="text-slate-600 text-[10px] font-bold italic">Sem visualização de mídia</span>
                          )}
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-black text-slate-400 uppercase mb-2 block">Relatório Detalhado</label>
                        <textarea 
                          className={`w-full bg-slate-800 border rounded-xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-blue-500 outline-none h-32 resize-none placeholder:text-slate-600 transition-all ${
                            [OccurrenceType.SEAL_DISCREPANCY, OccurrenceType.CARGO_EXCHANGE, OccurrenceType.SEAL_TAMPERED].includes(occType) && !occDescription.trim()
                              ? 'border-red-500/50 focus:border-red-500'
                              : 'border-slate-700'
                          }`}
                          placeholder="Descreva aqui qualquer irregularidade encontrada na auditoria do gate..."
                          value={occDescription}
                          onChange={(e) => setOccDescription(e.target.value)}
                        />
                        {[OccurrenceType.SEAL_DISCREPANCY, OccurrenceType.CARGO_EXCHANGE, OccurrenceType.SEAL_TAMPERED].includes(occType) && !occDescription.trim() && (
                          <p className="text-[10px] text-red-400 font-bold mt-1 uppercase tracking-tight animate-pulse">
                            A descrição é obrigatória para este tipo de ocorrência
                          </p>
                        )}
                      </div>

                      <div className="flex flex-col gap-3 pt-4">
                        <button 
                          onClick={handleSaveOccurrence}
                          disabled={
                            (occType !== OccurrenceType.NONE && (
                              !sealInput || 
                              (occType !== OccurrenceType.SEAL_DISCREPANCY && 
                               occType !== OccurrenceType.SEAL_TAMPERED && 
                               sealInput !== selectedLoad.sealNumber)
                            )) ||
                            ([OccurrenceType.SEAL_DISCREPANCY, OccurrenceType.CARGO_EXCHANGE, OccurrenceType.SEAL_TAMPERED].includes(occType) && !occDescription.trim())
                          }
                          className={`w-full font-black py-4 rounded-xl shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2 ${
                            (occType !== OccurrenceType.NONE && (
                              !sealInput || 
                              (occType !== OccurrenceType.SEAL_DISCREPANCY && 
                               occType !== OccurrenceType.SEAL_TAMPERED && 
                               sealInput !== selectedLoad.sealNumber)
                            )) ||
                            ([OccurrenceType.SEAL_DISCREPANCY, OccurrenceType.CARGO_EXCHANGE, OccurrenceType.SEAL_TAMPERED].includes(occType) && !occDescription.trim())
                            ? 'bg-slate-700 text-slate-500 cursor-not-allowed' 
                            : 'bg-blue-600 hover:bg-blue-500 text-white'
                          }`}
                        >
                          SALVAR RELATÓRIO DE AUDITORIA
                        </button>
                        {saveFeedback && (
                          <p className="text-center text-emerald-400 text-xs font-bold animate-pulse">Relatório salvo com sucesso no banco de dados.</p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl">
                    <div className="flex gap-3">
                      <svg className="w-5 h-5 text-amber-500 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd"></path></svg>
                      <p className="text-xs text-amber-800 leading-relaxed">
                        <strong>Importante:</strong> Qualquer ocorrência registrada como <strong>Divergência de Lacre</strong> ou <strong>Lacre Rompido</strong> deve ser comunicada imediatamente à Central de Monitoramento e Prevenção de Perdas. Anexe fotos nítidas do lacre e das dobradiças da porta.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-20 text-center">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
                  <svg className="w-10 h-10 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path></svg>
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-2">Aguardando Auditoria</h3>
                <p className="text-slate-500 max-w-sm">Selecione uma carga na lista lateral para iniciar o processo de conferência final e registro de ocorrências.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeSubTab === 'users' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-300">
          <div className="p-6 border-b bg-slate-50 flex justify-between items-center">
            <div>
              <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Gestão de Usuários</h3>
              <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Administração de contas e permissões</p>
            </div>
            {pendingUsers.length > 0 && (
              <span className="bg-red-100 text-red-600 text-[10px] font-black px-3 py-1 rounded-full animate-pulse">
                {pendingUsers.length} SOLICITAÇÃO(ÕES) PENDENTE(S)
              </span>
            )}
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {users.map(user => (
                <div key={user.id} className={`border rounded-2xl p-5 space-y-4 transition-all ${user.status === 'pending' ? 'border-amber-200 bg-amber-50/30' : 'border-slate-200 hover:border-blue-200'}`}>
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-black text-slate-800 uppercase tracking-tight truncate w-40">{user.fullName || user.username}</h4>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">{user.role}</span>
                        {user.systemRole && (
                          <span className="text-[10px] font-black text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded uppercase tracking-widest border border-purple-100">
                            {user.systemRole}
                          </span>
                        )}
                        <span className={`text-[8px] font-black px-1.5 py-0.5 rounded uppercase ${
                          user.status === 'active' ? 'bg-emerald-100 text-emerald-700' :
                          user.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {user.status}
                        </span>
                      </div>
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono">{new Date(user.createdAt).toLocaleDateString()}</span>
                  </div>
                  
                  <div className="space-y-2 bg-white/50 p-3 rounded-xl border border-slate-100/50">
                    <div className="flex justify-between">
                      <span className="text-[9px] font-black text-slate-400 uppercase">Usuário:</span>
                      <span className="text-[9px] font-bold text-slate-700">{user.username}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[9px] font-black text-slate-400 uppercase">Loja:</span>
                      <span className="text-[9px] font-bold text-slate-700">{user.storeLocation || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[9px] font-black text-slate-400 uppercase">Função:</span>
                      <span className="text-[9px] font-bold text-slate-700">{user.jobFunction || 'N/A'}</span>
                    </div>
                    <div className="flex flex-col gap-1 pt-1 border-t border-slate-100 mt-1">
                      <span className="text-[9px] font-black text-slate-400 uppercase">Perfil de Sistema:</span>
                      <select 
                        className="text-[9px] font-bold text-blue-700 bg-blue-50 border-none rounded px-1 py-0.5 outline-none focus:ring-1 focus:ring-blue-300"
                        value={user.systemRole || 'viewer'}
                        onChange={(e) => onUpdateSystemRole(user.id, e.target.value as SystemRole)}
                        disabled={user.status !== 'active'}
                      >
                        <option value="administrator">Administrador</option>
                        <option value="dispatcher">Expedidor</option>
                        <option value="auditor">Auditor</option>
                        <option value="viewer">Visualizador</option>
                      </select>
                    </div>
                  </div>

                  {user.status === 'pending' ? (
                    <div className="flex gap-2 pt-2">
                      <button 
                        onClick={() => onApproveUser(user.id, true)}
                        className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-black py-2.5 rounded-xl shadow-sm transition-all"
                      >
                        APROVAR
                      </button>
                      <button 
                        onClick={() => onApproveUser(user.id, false)}
                        className="flex-1 bg-white border border-red-200 text-red-600 hover:bg-red-50 text-[10px] font-black py-2.5 rounded-xl transition-all"
                      >
                        REJEITAR
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2 pt-2">
                      {editingUserId === user.id ? (
                        <div className="space-y-2 animate-in slide-in-from-top-2 duration-200">
                          <input 
                            type="password"
                            placeholder="Nova senha"
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-bold outline-none focus:ring-2 focus:ring-blue-500"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                          />
                          <div className="flex gap-2">
                            <button 
                              onClick={() => {
                                if (newPassword.trim()) {
                                  onChangePassword(user.id, newPassword);
                                  setEditingUserId(null);
                                  setNewPassword('');
                                }
                              }}
                              className="flex-1 bg-blue-600 text-white text-[9px] font-black py-2 rounded-lg"
                            >
                              CONFIRMAR
                            </button>
                            <button 
                              onClick={() => {
                                setEditingUserId(null);
                                setNewPassword('');
                              }}
                              className="flex-1 bg-slate-100 text-slate-600 text-[9px] font-black py-2 rounded-lg"
                            >
                              CANCELAR
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex gap-2">
                          <button 
                            onClick={() => setEditingUserId(user.id)}
                            className="flex-1 bg-slate-100 hover:bg-blue-50 text-blue-600 text-[9px] font-black py-2 rounded-lg transition-all flex items-center justify-center gap-1"
                          >
                            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"></path></svg>
                            SENHA
                          </button>
                          <button 
                            onClick={() => {
                              if (confirm(`Tem certeza que deseja excluir o usuário ${user.username}?`)) {
                                onDeleteUser(user.id);
                              }
                            }}
                            className="flex-1 bg-slate-100 hover:bg-red-50 text-red-600 text-[9px] font-black py-2 rounded-lg transition-all flex items-center justify-center gap-1"
                          >
                            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                            EXCLUIR
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'logs' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-300">
          <div className="p-6 border-b bg-slate-900 flex justify-between items-center">
            <div>
              <h3 className="text-xl font-black text-white uppercase tracking-tight">Log de Eventos Global</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Rastreabilidade total das operações do sistema</p>
            </div>
            <button 
              onClick={exportToPDF}
              className="bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-black px-4 py-2 rounded-lg shadow-lg transition-all flex items-center gap-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
              EXPORT PDF
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Data/Hora</th>
                  <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Usuário</th>
                  <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Ação</th>
                  <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Detalhes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {logs.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-6 py-20 text-center text-slate-400 italic text-sm">Nenhum evento registrado.</td>
                  </tr>
                ) : (
                  logs.map(log => (
                    <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 text-[10px] font-mono text-slate-500">{new Date(log.timestamp).toLocaleString()}</td>
                      <td className="px-6 py-4">
                        <span className="text-[11px] font-black text-slate-800 uppercase tracking-tight">{log.username}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-[9px] font-black px-2 py-1 rounded-full uppercase tracking-tighter ${
                          log.action.includes('Login') ? 'bg-blue-100 text-blue-700' :
                          log.action.includes('Criação') ? 'bg-emerald-100 text-emerald-700' :
                          log.action.includes('Auditoria') ? 'bg-amber-100 text-amber-700' :
                          'bg-slate-100 text-slate-700'
                        }`}>
                          {log.action}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-xs text-slate-600 font-medium">{log.details}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
