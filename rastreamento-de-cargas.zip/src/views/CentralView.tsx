
import React, { useState, useEffect } from 'react';
import { CargoLoad, CargoStatus } from '../types';
import { GoogleGenAI } from "@google/genai";

interface CentralViewProps {
  loads: CargoLoad[];
  onUpdateStatus: (id: string, newStatus: CargoStatus) => void;
}

interface GroundingLink {
  uri: string;
  title: string;
}

const CD_ROUTES_MAP: Record<string, string> = {
  '07 SIA': 'https://maps.app.goo.gl/PBtxevHVVLT52hkE6',
  '28 AGUA CLARAS': 'https://maps.app.goo.gl/fLyaodjLhw2xAG96A',
  '29 GUARA': 'https://maps.app.goo.gl/GyiRoPxwguNuAvb68',
  '42 JARDIM BOTANICO': 'https://maps.app.goo.gl/YZQ6NS3mdBtaeQJ4A',
  '25 NOVO GAMA': 'https://maps.app.goo.gl/gcyQ98LmSQGHK1W89',
  '13 LUZIANIA': 'https://maps.app.goo.gl/nDP7gmVKzk2Wjb3r8',
  '16 SANTO ANTONIO': 'https://maps.app.goo.gl/NfqWzTjrvwfcyTX69',
  '32 CEILADIA CENTRO': 'https://maps.app.goo.gl/kg4bvxXec9ZfZRqS9',
  '01 BRR 070': 'https://maps.app.goo.gl/uKxtH1ZxHCeY2EvD7',
  '21 CEILANDIA SUL': 'https://maps.app.goo.gl/JVSvAGRhJMt7HRqh7',
  '55 RECANTO DAS EMAS': 'https://maps.app.goo.gl/Fp9KMhuiAa6Yuo697',
  '34 SAMABAIA SUL': 'https://maps.app.goo.gl/eBrRrTfBdEox2myv9',
  '60 FURNAS': 'https://maps.app.goo.gl/QCTVWZFgkEEKMADq6',
  '08 TAGUATINGA': 'https://maps.app.goo.gl/Xvpo2U5zcDr7uQvr5',
  '58 ETPG': 'https://maps.app.goo.gl/PiGKFca7AXfxzTLm9',
  '38 VICENTE RUA 04': 'https://maps.app.goo.gl/JeEqmN2qw4eRHoXU9',
  '37 VICENTE RUA 012': 'https://maps.app.goo.gl/SVZFqWbXizTtFzHt9',
  '56 RIACHO': 'https://maps.app.goo.gl/ZxvxrLMfyHMLDE3v6',
  '18 AGUAS LINDAS': 'https://maps.app.goo.gl/MmKcmGXc5bQCsL1c9',
  '33 PLANALDINA DF': 'https://maps.app.goo.gl/KWq2RxBLGr1hz3cm8',
  '27 PLANALTINA GO': 'https://maps.app.goo.gl/HvL5LVvpj5MGfG8i6',
  '50 MESTRE DARMAS': 'https://maps.app.goo.gl/r3QHeCnZUdBoKkMg9',
  '63 FORMOSA': 'https://maps.app.goo.gl/gNfKqUSc3rLHHUBg9',
  '40 GURUPI': 'https://maps.app.goo.gl/FDSduwU6itANrKdG7',
  '30 LEM': 'https://maps.app.goo.gl/FkXxQwGWeTkcWs4W9',
  '19 CALDAS NOVAS': 'https://maps.app.goo.gl/97R82Ndp4gXHUfkCA',
  '47 AP. GOIANAIA': 'https://maps.app.goo.gl/pRkLd93jsGRfdqTn8',
  '15 BALNEARIO': 'https://maps.app.goo.gl/LMRRWafipxzFb2v68',
  '26 CESAR LATTES': 'https://maps.app.goo.gl/RqXqVbVsR4tyFVQ48',
  '12 GAMA': 'https://maps.app.goo.gl/m1RwuPXug34YpTCF8',
  '39 GOIANESIA': 'https://maps.app.goo.gl/QdDE4WHFAFybXzwt8',
  '64 ITUBIARA': 'https://maps.app.goo.gl/96r6RMNutDv3pJE48',
  '62 LUZIANAIA 2': 'https://maps.app.goo.gl/8MJ61nvvXd2xeMSW7',
  '53 RIO VERDE': 'https://maps.app.goo.gl/k7u5rBVEMztQXwLB8',
  '04 SOBRADINHO': 'https://maps.app.goo.gl/SqwryjCHfvb2qKZd6'
};

export const CentralView: React.FC<CentralViewProps> = ({ loads, onUpdateStatus }) => {
  const [selectedLoadId, setSelectedLoadId] = useState<string | null>(null);
  const [sealInput, setSealInput] = useState('');
  const [verificationFeedback, setVerificationFeedback] = useState<{ type: 'error' | 'success' | null, message: string }>({ type: null, message: '' });
  
  const [isCalculatingRoute, setIsCalculatingRoute] = useState(false);
  const [routeInfo, setRouteInfo] = useState<string | null>(null);
  const [routeLinks, setRouteLinks] = useState<GroundingLink[]>([]);
  const [mapEmbedUrl, setMapEmbedUrl] = useState<string | null>(null);

  const selectedLoad = loads.find(l => l.id === selectedLoadId);

  // Detect if a predefined route link exists for the primary destination
  const staticRouteLink = (selectedLoad?.origin.startsWith('CD') && selectedLoad?.destination) 
    ? CD_ROUTES_MAP[selectedLoad.destination] 
    : null;

  useEffect(() => {
    if (selectedLoad) {
      // 1. Build the list of waypoints
      const allDestinations = [selectedLoad.destination, ...(selectedLoad.additionalDestinations || [])];
      
      // 2. Enhance strings for better Google Maps lookup
      const originQuery = `Atacadista Dia a Dia ${selectedLoad.origin}, Brasília`;
      const destQueries = allDestinations.map(d => `Atacadista Dia a Dia ${d}, Brasília`);
      
      // 3. Construct the Google Maps Directions Embed URL
      // Format: maps.google.com/maps?saddr=ORIGIN&daddr=DEST1+to:DEST2&output=embed
      const saddr = encodeURIComponent(originQuery);
      const daddr = destQueries.map(d => encodeURIComponent(d)).join('+to:');
      
      const embedUrl = `https://maps.google.com/maps?saddr=${saddr}&daddr=${daddr}&output=embed&t=m&z=12`;
      setMapEmbedUrl(embedUrl);

      // Add the official static link to route references if it exists
      if (staticRouteLink) {
        setRouteLinks([{ uri: staticRouteLink, title: "Itinerário Oficial (Link Externo)" }]);
      }
    } else {
      setMapEmbedUrl(null);
      setRouteLinks([]);
    }
  }, [selectedLoadId, staticRouteLink]);

  const handleVerify = () => {
    if (!selectedLoad) return;
    if (sealInput.trim().toUpperCase() === selectedLoad.sealNumber.trim().toUpperCase()) {
      setVerificationFeedback({ 
        type: 'success', 
        message: '✓ LACRE VALIDADO COM SUCESSO: A integridade da carga foi confirmada e a liberação está autorizada.' 
      });
    } else {
      setVerificationFeedback({ 
        type: 'error', 
        message: '⚠ DIVERGÊNCIA CRÍTICA DE LACRE: O número digitado não confere com o registro. BLOQUEIO PREVENTIVO ATIVADO.' 
      });
    }
  };

  const handleAuthorize = () => {
    if (selectedLoad && sealInput === selectedLoad.sealNumber) {
      onUpdateStatus(selectedLoad.id, CargoStatus.RELEASED);
      setVerificationFeedback({ type: 'success', message: 'AUTORIZAÇÃO CONCEDIDA: CARGA LIBERADA' });
      setSealInput('');
    }
  };

  const calculateAiInsights = async () => {
    if (!selectedLoad) return;
    setIsCalculatingRoute(true);
    setRouteInfo(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      let userLocation = undefined;
      try {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 5000 });
        });
        userLocation = { latitude: position.coords.latitude, longitude: position.coords.longitude };
      } catch (e) { console.warn("Geolocation skipped", e); }

      const allDestinations = [selectedLoad.destination, ...(selectedLoad.additionalDestinations || [])];
      const prompt = `Como especialista em logística, analise o trajeto da frota saindo de ${selectedLoad.origin} (Atacadista Dia a Dia) para as entregas em: ${allDestinations.join(', ')}. 
      Forneça:
      1. Estimativa de tempo total considerando o tráfego de carga pesada.
      2. Ordem de entrega sugerida para maior eficiência de combustível.
      3. Pontos de atenção no trajeto (obras, restrições de caminhões).`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          tools: [{ googleMaps: {} }],
          ...(userLocation && { toolConfig: { retrievalConfig: { latLng: userLocation } } })
        },
      });

      setRouteInfo(response.text || "Análise logística concluída.");
      
      const grounding = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (grounding) {
        const newLinks: GroundingLink[] = grounding
          .filter((c: any) => c.maps)
          .map((c: any) => ({
            uri: c.maps.uri,
            title: c.maps.title || "Referência Geográfica"
          }));
          
        setRouteLinks(prev => {
          const existingUris = new Set(prev.map(l => l.uri));
          const uniqueNewLinks = newLinks.filter(l => !existingUris.has(l.uri));
          return [...prev, ...uniqueNewLinks];
        });
      }
    } catch (error) {
      console.error("AI Insights error:", error);
      setRouteInfo("Indisponível: Verifique a conexão com os serviços de inteligência geográfica.");
    } finally {
      setIsCalculatingRoute(false);
    }
  };

  const pendingLoads = loads.filter(l => l.status === CargoStatus.AWAITING);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-end gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-800 tracking-tight">Painel Central de Monitoramento</h2>
          <p className="text-slate-500 font-medium">Validação de lacres e autorização de despacho em tempo real.</p>
        </div>
        <div className="flex gap-3">
          <div className="bg-white px-5 py-3 rounded-xl border border-slate-200 shadow-sm flex flex-col items-center">
            <span className="text-[10px] uppercase font-bold text-slate-400">Em Conferência</span>
            <span className="text-xl font-black text-amber-500">{pendingLoads.length}</span>
          </div>
          <div className="bg-white px-5 py-3 rounded-xl border border-slate-200 shadow-sm flex flex-col items-center">
            <span className="text-[10px] uppercase font-bold text-slate-400">Cargas Liberadas</span>
            <span className="text-xl font-black text-emerald-500">{loads.filter(l => l.status === CargoStatus.RELEASED).length}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: List of manifestos */}
        <div className="lg:col-span-4 xl:col-span-3 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col h-[750px]">
          <div className="p-5 border-b bg-slate-50/50 rounded-t-2xl flex justify-between items-center">
            <h3 className="font-bold text-slate-700 flex items-center gap-2">
              <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"></path></svg>
              Lista de Saída
            </h3>
            <span className="text-[10px] bg-slate-200 px-2 py-1 rounded-full font-bold text-slate-600">AUTO-REFRESH</span>
          </div>
          <div className="overflow-y-auto flex-1 p-3 space-y-3">
            {pendingLoads.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center px-6">
                <svg className="w-12 h-12 mb-3 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                <p className="text-sm font-medium">Fluxo limpo. Todas as cargas foram processadas ou não há registros.</p>
              </div>
            ) : (
              pendingLoads.map((load) => (
                <button
                  key={load.id}
                  onClick={() => {
                    setSelectedLoadId(load.id);
                    setVerificationFeedback({ type: null, message: '' });
                    setSealInput('');
                    setRouteInfo(null);
                    setRouteLinks([]);
                  }}
                  className={`w-full text-left p-4 rounded-xl border transition-all duration-200 group ${
                    selectedLoadId === load.id 
                      ? 'border-blue-500 bg-blue-50 ring-4 ring-blue-50' 
                      : 'border-slate-100 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-mono font-black text-lg text-slate-800 tracking-tighter group-hover:text-blue-600 transition-colors">{load.plate}</span>
                    <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-tight ${load.isHighRisk ? 'bg-red-500 text-white shadow-sm' : 'bg-slate-200 text-slate-600'}`}>
                      {load.isHighRisk ? 'ALTO RISCO' : 'PADRÃO'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
                    <span className="truncate max-w-[80px]">{load.origin}</span>
                    <svg className="w-3 h-3 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                    <span className="truncate text-blue-600">{load.destination}</span>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Right Column: Detailed Verification & Map */}
        <div className="lg:col-span-8 xl:col-span-9 flex flex-col gap-6">
          {selectedLoad ? (
            <>
              {/* Map Section - Integrated Interactivity */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
                <div className="p-5 border-b bg-slate-50/50 flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"></path></svg>
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800">Visualização de Itinerário Integrada</h4>
                      <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Geolocalização Atacadista Dia a Dia</p>
                    </div>
                  </div>
                  <button 
                    onClick={calculateAiInsights} 
                    disabled={isCalculatingRoute}
                    className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-slate-800 disabled:opacity-50 transition-all shadow-md active:scale-95"
                  >
                    {isCalculatingRoute ? (
                      <span className="flex items-center gap-2 italic"><svg className="animate-spin h-3 w-3 text-white" viewBox="0 0 24 24"></svg> ANALISANDO...</span>
                    ) : (
                      <>
                        <svg className="w-4 h-4 text-blue-400" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M11.3 1.047a1 1 0 01.897.95L12.5 7h5a1 1 0 01.545 1.835l-9 6a1 1 0 01-1.428-1.229l1.458-5.385-4.32-.288a1 1 0 01-.894-1.448l6-9a1 1 0 011.439-.288z" clipRule="evenodd"></path></svg>
                        INSIGHTS LOGÍSTICOS IA
                      </>
                    )}
                  </button>
                </div>
                
                <div className="relative w-full h-[450px] bg-slate-100">
                  {mapEmbedUrl ? (
                    <iframe
                      title="Route Map"
                      src={mapEmbedUrl}
                      className="w-full h-full border-0"
                      allowFullScreen
                      loading="lazy"
                    ></iframe>
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 gap-2">
                      <svg className="w-12 h-12 opacity-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                      <span className="text-sm font-bold">AGUARDANDO COORDENADAS</span>
                    </div>
                  )}
                  
                  {/* AI Floating Info Panel */}
                  {routeInfo && (
                    <div className="absolute bottom-4 left-4 right-4 max-h-[150px] overflow-y-auto bg-white/95 backdrop-blur shadow-2xl rounded-xl border border-blue-200 p-4 animate-in slide-in-from-bottom-5 duration-300">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
                        <h5 className="text-[10px] font-black uppercase text-blue-700">Relatório de Inteligência</h5>
                      </div>
                      <p className="text-xs text-slate-700 leading-relaxed font-medium whitespace-pre-line">{routeInfo}</p>
                    </div>
                  )}
                </div>

                {routeLinks.length > 0 && (
                  <div className="p-4 bg-slate-50 border-t flex flex-wrap gap-2">
                    {routeLinks.map((link, i) => (
                      <a 
                        key={i} 
                        href={link.uri} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-[10px] font-bold text-slate-700 hover:border-blue-400 hover:text-blue-600 transition-all shadow-sm"
                      >
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
                        {link.title}
                      </a>
                    ))}
                  </div>
                )}
              </div>

              {/* Data & Security Section */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Info Card */}
                <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
                  <h4 className="font-bold text-slate-800 border-b pb-3 flex items-center gap-2">
                    <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Manifesto de Carga
                  </h4>
                  <div className="grid grid-cols-2 gap-y-5 gap-x-2">
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase">Motorista</p>
                      <p className="text-sm font-bold text-slate-800 truncate">{selectedLoad.driverName}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase">Criado por</p>
                      <p className="text-sm font-bold text-slate-800 truncate">{selectedLoad.createdBy}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase">Volume (Paletes)</p>
                      <div className="flex flex-col">
                        <p className="text-sm font-bold text-slate-800">{selectedLoad.palletCount} un</p>
                        {selectedLoad.palletDetails && selectedLoad.palletDetails.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {selectedLoad.palletDetails.map((p, i) => (
                              <span key={i} className="text-[8px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded border border-slate-200 font-black uppercase">
                                {p.quantity}x {p.type}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase">Tipo Operacional</p>
                      <p className="text-sm font-bold text-slate-800 truncate">{selectedLoad.cargoType}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase">Status Geral</p>
                      <span className="text-[10px] font-black px-2 py-0.5 rounded bg-amber-100 text-amber-700 border border-amber-200 uppercase">{selectedLoad.status}</span>
                    </div>
                  </div>
                  
                  {selectedLoad.isHighRisk && (
                    <div className="p-4 bg-red-50 border border-red-100 rounded-xl space-y-3">
                      <div className="flex gap-3">
                        <div className="text-red-500 mt-0.5">
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd"></path></svg>
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-red-700 uppercase tracking-widest">Alerta de Carga PAR</p>
                          <div className="mt-1 grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                              <p className="text-[9px] font-bold text-red-400 uppercase">Item PAR</p>
                              <p className="text-xs font-bold text-red-900">{selectedLoad.parType}</p>
                            </div>
                            <div>
                              <p className="text-[9px] font-bold text-red-400 uppercase">Nota Fiscal</p>
                              <p className="text-xs font-bold text-red-900">{selectedLoad.parInvoiceNumber}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      {selectedLoad.parDescription && (
                        <div className="pt-2 border-t border-red-200/50">
                          <p className="text-[9px] font-bold text-red-400 uppercase">Observações Adicionais</p>
                          <p className="text-xs font-medium text-red-900 leading-snug">{selectedLoad.parDescription}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Validation Card */}
                <div className="bg-slate-900 rounded-2xl shadow-xl p-6 text-white flex flex-col justify-between">
                  <div>
                    <h4 className="font-bold text-blue-400 mb-1 flex items-center gap-2">
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>
                      Gate de Segurança
                    </h4>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-6">Conferência de Integridade Física</p>
                    
                    <div className="space-y-4">
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="DIGITE O LACRE..."
                          className={`flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 font-mono text-xl tracking-[0.2em] outline-none focus:ring-2 focus:ring-blue-500 placeholder:text-slate-600 uppercase transition-all ${
                            verificationFeedback.type === 'success' ? 'opacity-50 cursor-not-allowed border-emerald-500/50 text-emerald-400' : ''
                          }`}
                          value={sealInput}
                          disabled={verificationFeedback.type === 'success'}
                          onChange={(e) => { setSealInput(e.target.value); setVerificationFeedback({ type: null, message: '' }); }}
                        />
                        <button 
                          onClick={handleVerify}
                          disabled={verificationFeedback.type === 'success'}
                          className={`px-6 rounded-xl font-black text-xs transition-all active:scale-95 ${
                            verificationFeedback.type === 'success' 
                              ? 'bg-emerald-600 text-white opacity-50 cursor-not-allowed' 
                              : 'bg-blue-600 hover:bg-blue-500 text-white'
                          }`}
                        >
                          {verificationFeedback.type === 'success' ? 'VALIDADO' : 'VALIDAR'}
                        </button>
                      </div>
                      
                      {verificationFeedback.message && (
                        <div className={`p-4 rounded-xl text-[10px] font-black tracking-wide border animate-in slide-in-from-top-2 duration-300 ${
                          verificationFeedback.type === 'success' 
                            ? 'bg-emerald-950/30 text-emerald-400 border-emerald-500/50' 
                            : 'bg-red-950/30 text-red-400 border-red-500/50'
                        }`}>
                          <span className="flex items-center gap-2">
                            {verificationFeedback.type === 'success' ? '✓ ' : '⚠ '}
                            {verificationFeedback.message}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  <button 
                    disabled={verificationFeedback.type !== 'success'} 
                    onClick={handleAuthorize} 
                    className={`w-full py-5 mt-8 rounded-xl font-black text-lg tracking-widest transition-all shadow-lg flex items-center justify-center gap-3 ${
                      verificationFeedback.type === 'success' 
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white transform hover:-translate-y-1 active:scale-95' 
                        : 'bg-slate-800 text-slate-600 cursor-not-allowed opacity-50'
                    }`}
                  >
                    {verificationFeedback.type === 'success' && <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path></svg>}
                    AUTORIZAR SAÍDA
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-20 text-center bg-white rounded-3xl border-2 border-dashed border-slate-200">
              <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mb-6">
                <svg className="w-12 h-12 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122"></path></svg>
              </div>
              <h3 className="text-2xl font-black text-slate-800 mb-2">Aguardando Seleção</h3>
              <p className="max-w-md text-slate-500 font-medium">Selecione uma placa na lista à esquerda para carregar os dados geográficos, conferir o lacre e processar a liberação do veículo.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
