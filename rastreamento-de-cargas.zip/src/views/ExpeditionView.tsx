
import React, { useState } from 'react';
import { CargoLoad, CargoType, EventLog } from '../types';

interface ExpeditionViewProps {
  onSubmit: (load: Omit<CargoLoad, 'id' | 'status' | 'createdAt' | 'createdBy'>) => void;
  logs: EventLog[];
}

const LOCATION_OPTIONS = [
  'CD-01', 'CD-02', '01 BRR 070', '04 SOBRADINHO', '07 SIA', '08 TAGUATINGA',
  '12 GAMA', '13 LUZIANIA', '15 BALNEARIO', '16 SANTO ANTONIO', '18 AGUAS LINDAS',
  '19 CALDAS NOVAS', '21 CEILANDIA SUL', '25 NOVO GAMA', '26 CESAR LATTES',
  '27 PLANALTINA GO', '28 AGUA CLARAS', '29 GUARA', '30 LEM', '32 CEILADIA CENTRO',
  '33 PLANALDINA DF', '34 SAMABAIA SUL', '37 VICENTE RUA 012', '38 VICENTE RUA 04',
  '39 GOIANESIA', '40 GURUPI', '42 JARDIM BOTANICO', '47 AP. GOIANAIA',
  '50 MESTRE DARMAS', '53 RIO VERDE', '55 RECANTO DAS EMAS', '56 RIACHO',
  '58 ETPG', '60 FURNAS', '62 LUZIANAIA 2', '63 FORMOSA', '64 ITUBIARA'
];

const PAR_OPTIONS = [
  'whisky', 'GILETE', 'PILHAS', 'BACON', 'MUSSARELA', 'CAFE', 
  'PICANHA', 'PNEUS', 'RED BULL', 'heineken', 'BOMBONIERE'
];

export const ExpeditionView: React.FC<ExpeditionViewProps> = ({ onSubmit, logs }) => {
  const [formData, setFormData] = useState({
    plate: '',
    driverName: '',
    cargoType: CargoType.FLV,
    origin: LOCATION_OPTIONS[0],
    destination: LOCATION_OPTIONS[1] || LOCATION_OPTIONS[0],
    additionalDestinations: [] as string[],
    isHighRisk: false,
    parType: '',
    parInvoiceNumber: '',
    parDescription: '',
    sealNumber: '',
    palletCount: 0,
    palletDetails: [] as { type: string; quantity: number }[],
  });

  const PALLET_TYPES = [
    'Palete PBR',
    'Palete CHEP',
    'Gaiola',
    'Bins',
    'Caixa IFCO'
  ];

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validatePlate = (plate: string) => {
    const regex = /^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/;
    return regex.test(plate.toUpperCase());
  };

  const toggleAdditionalDestination = (loc: string) => {
    setFormData(prev => {
      const isSelected = prev.additionalDestinations.includes(loc);
      if (isSelected) {
        return { ...prev, additionalDestinations: prev.additionalDestinations.filter(d => d !== loc) };
      } else {
        return { ...prev, additionalDestinations: [...prev.additionalDestinations, loc] };
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};

    if (!validatePlate(formData.plate)) {
      newErrors.plate = 'Placa inválida. Use o formato Mercosul (ex: ABC1D23)';
    }
    if (!formData.driverName.trim()) {
      newErrors.driverName = 'Nome do motorista é obrigatório';
    }
    if (!formData.sealNumber.trim()) {
      newErrors.sealNumber = 'Número do lacre é crítico';
    }
    if (formData.palletCount < 1) {
      newErrors.palletCount = 'Mínimo de 1 palete no total';
    }
    if (formData.palletDetails.length === 0) {
      newErrors.palletDetails = 'Selecione pelo menos um tipo de palete';
    }
    if (formData.isHighRisk) {
      if (!formData.parType) {
        newErrors.parType = 'Selecione o tipo de PAR';
      }
      if (!formData.parInvoiceNumber.trim()) {
        newErrors.parInvoiceNumber = 'Número da nota do PAR é obrigatório';
      }
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    onSubmit(formData);
    setFormData({
      plate: '',
      driverName: '',
      cargoType: CargoType.FLV,
      origin: LOCATION_OPTIONS[0],
      destination: LOCATION_OPTIONS[1] || LOCATION_OPTIONS[0],
      additionalDestinations: [],
      isHighRisk: false,
      parType: '',
      parInvoiceNumber: '',
      parDescription: '',
      sealNumber: '',
      palletCount: 0,
      palletDetails: [],
    });
    setErrors({});
  };

  const inputClass = (error?: string) => `
    w-full bg-slate-900 text-white border rounded-lg px-4 py-2.5 
    focus:ring-2 focus:ring-blue-500 outline-none transition-all 
    placeholder:text-slate-500
    ${error ? 'border-red-500' : 'border-slate-700'}
  `;

  const selectClass = `
    w-full bg-slate-900 text-white border border-slate-700 rounded-lg px-4 py-2.5 
    focus:ring-2 focus:ring-blue-500 outline-none transition-all appearance-none cursor-pointer
  `;

  return (
    <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="bg-slate-50 px-8 py-6 border-b border-slate-200">
          <h2 className="text-2xl font-bold text-slate-800">Coleta de Dados</h2>
          <p className="text-slate-500 mt-1">Expedição: Registro de saída de carga.</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex flex-col gap-1">
              <label className="text-sm font-semibold text-slate-700">Placa do Caminhão</label>
              <input
                type="text"
                placeholder="ABC1D23"
                className={`${inputClass(errors.plate)} uppercase`}
                value={formData.plate}
                onChange={(e) => setFormData({ ...formData, plate: e.target.value.toUpperCase() })}
              />
              {errors.plate && <span className="text-red-500 text-xs font-medium">{errors.plate}</span>}
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-semibold text-slate-700">Nome do Motorista</label>
              <input
                type="text"
                placeholder="Nome do Condutor"
                className={inputClass(errors.driverName)}
                value={formData.driverName}
                onChange={(e) => setFormData({ ...formData, driverName: e.target.value })}
              />
              {errors.driverName && <span className="text-red-500 text-xs font-medium">{errors.driverName}</span>}
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-semibold text-slate-700">Origem</label>
              <div className="relative">
                <select
                  className={selectClass}
                  value={formData.origin}
                  onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                >
                  {LOCATION_OPTIONS.map((loc) => (
                    <option key={`origin-${loc}`} value={loc}>{loc}</option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none text-slate-400">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-semibold text-slate-700">Primeiro Destino</label>
              <div className="relative">
                <select
                  className={selectClass}
                  value={formData.destination}
                  onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                >
                  {LOCATION_OPTIONS.map((loc) => (
                    <option key={`dest-${loc}`} value={loc}>{loc}</option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none text-slate-400">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-semibold text-slate-700">Tipo de Carga</label>
              <div className="relative">
                <select
                  className={selectClass}
                  value={formData.cargoType}
                  onChange={(e) => setFormData({ ...formData, cargoType: e.target.value as CargoType })}
                >
                  {Object.values(CargoType).map((type) => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none text-slate-400">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-semibold text-slate-700">Classificação de Paletes</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-3 bg-slate-50 border border-slate-200 rounded-lg">
                {PALLET_TYPES.map((type) => {
                  const isSelected = formData.palletDetails.some(p => p.type === type);
                  return (
                    <label key={type} className={`
                      flex items-center gap-2 p-2 rounded border cursor-pointer transition-all text-[10px] font-bold uppercase
                      ${isSelected 
                        ? 'bg-blue-600 text-white border-blue-700' 
                        : 'bg-white text-slate-600 border-slate-100 hover:border-blue-300'}
                    `}>
                      <input 
                        type="checkbox" 
                        className="sr-only"
                        checked={isSelected}
                        onChange={() => {
                          let newDetails;
                          if (isSelected) {
                            newDetails = formData.palletDetails.filter(p => p.type !== type);
                          } else {
                            newDetails = [...formData.palletDetails, { type, quantity: 1 }];
                          }
                          const total = newDetails.reduce((acc, curr) => acc + curr.quantity, 0);
                          setFormData({ ...formData, palletDetails: newDetails, palletCount: total });
                        }}
                      />
                      <span className="truncate">{type}</span>
                    </label>
                  );
                })}
              </div>
              {errors.palletDetails && <span className="text-red-500 text-xs font-medium">{errors.palletDetails}</span>}
            </div>

            {formData.palletDetails.length > 0 && (
              <div className="flex flex-col gap-2 p-4 bg-slate-50 border border-slate-200 rounded-lg animate-in slide-in-from-top-2 duration-200">
                <label className="text-sm font-semibold text-slate-700">Quantificar Paletes</label>
                <div className="space-y-3">
                  {formData.palletDetails.map((pallet, index) => (
                    <div key={pallet.type} className="flex items-center justify-between gap-4 bg-white p-2 rounded border border-slate-100 shadow-sm">
                      <span className="text-[10px] font-black text-slate-500 uppercase">{pallet.type}</span>
                      <div className="flex items-center gap-2">
                        <button 
                          type="button"
                          onClick={() => {
                            const newDetails = [...formData.palletDetails];
                            if (newDetails[index].quantity > 1) {
                              newDetails[index].quantity -= 1;
                              const total = newDetails.reduce((acc, curr) => acc + curr.quantity, 0);
                              setFormData({ ...formData, palletDetails: newDetails, palletCount: total });
                            }
                          }}
                          className="w-8 h-8 flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg transition-colors"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          min="1"
                          className="w-16 text-center bg-transparent font-bold text-slate-800 outline-none"
                          value={pallet.quantity}
                          onChange={(e) => {
                            const val = parseInt(e.target.value) || 1;
                            const newDetails = [...formData.palletDetails];
                            newDetails[index].quantity = val;
                            const total = newDetails.reduce((acc, curr) => acc + curr.quantity, 0);
                            setFormData({ ...formData, palletDetails: newDetails, palletCount: total });
                          }}
                        />
                        <button 
                          type="button"
                          onClick={() => {
                            const newDetails = [...formData.palletDetails];
                            newDetails[index].quantity += 1;
                            const total = newDetails.reduce((acc, curr) => acc + curr.quantity, 0);
                            setFormData({ ...formData, palletDetails: newDetails, palletCount: total });
                          }}
                          className="w-8 h-8 flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg transition-colors"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  ))}
                  <div className="pt-2 border-t border-slate-200 flex justify-between items-center">
                    <span className="text-xs font-black text-slate-800 uppercase">Total Geral</span>
                    <span className="text-lg font-black text-blue-600">{formData.palletCount}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Carga Compartilhada - Multi-Destinos */}
          {formData.cargoType === CargoType.COMPARTILHADA && (
            <div className="p-6 bg-blue-50 border border-blue-200 rounded-xl space-y-4 animate-in slide-in-from-top-4 duration-300">
              <div className="flex items-center gap-2 text-blue-800">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd"></path></svg>
                <h4 className="font-bold">Lojas de Destino Adicionais</h4>
              </div>
              <p className="text-xs text-blue-600 font-medium">Selecione todas as lojas que receberão parte desta carga.</p>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-2 bg-white rounded-lg border border-blue-100">
                {LOCATION_OPTIONS.filter(l => l !== formData.destination && l !== formData.origin).map((loc) => (
                  <label key={`add-${loc}`} className={`
                    flex items-center gap-2 p-2 rounded border cursor-pointer transition-all text-[10px] font-bold uppercase
                    ${formData.additionalDestinations.includes(loc) 
                      ? 'bg-blue-600 text-white border-blue-700' 
                      : 'bg-white text-slate-600 border-slate-100 hover:border-blue-300'}
                  `}>
                    <input 
                      type="checkbox" 
                      className="sr-only"
                      checked={formData.additionalDestinations.includes(loc)}
                      onChange={() => toggleAdditionalDestination(loc)}
                    />
                    <span className="truncate">{loc}</span>
                  </label>
                ))}
              </div>
              {formData.additionalDestinations.length > 0 && (
                <div className="text-[10px] text-blue-700 font-bold">
                  Selecionadas: {formData.additionalDestinations.join(', ')}
                </div>
              )}
            </div>
          )}

          <div className="flex flex-col gap-1">
            <label className="text-sm font-semibold text-slate-700">Número do Lacre</label>
            <input
              type="text"
              placeholder="Digite o número do lacre físico"
              className={`${inputClass(errors.sealNumber)} font-mono tracking-widest`}
              value={formData.sealNumber}
              onChange={(e) => setFormData({ ...formData, sealNumber: e.target.value })}
            />
            {errors.sealNumber && <span className="text-red-500 text-xs font-medium">{errors.sealNumber}</span>}
          </div>

          <div className="space-y-4 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-3">
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  className="sr-only peer" 
                  checked={formData.isHighRisk}
                  onChange={(e) => setFormData({ ...formData, isHighRisk: e.target.checked, parDescription: e.target.checked ? formData.parDescription : '' })}
                />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-red-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600"></div>
                <span className="ml-3 text-sm font-bold text-slate-700">PAR (Produtos de Alto Risco)</span>
              </label>
            </div>

            {formData.isHighRisk && (
              <div className="animate-in slide-in-from-top-2 duration-200 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <label className="text-sm font-semibold text-slate-700">Tipo de PAR</label>
                    <div className="relative">
                      <select
                        className={selectClass}
                        value={formData.parType}
                        onChange={(e) => setFormData({ ...formData, parType: e.target.value })}
                      >
                        <option value="">Selecione um item...</option>
                        {PAR_OPTIONS.map((opt) => (
                          <option key={opt} value={opt}>{opt}</option>
                        ))}
                      </select>
                      <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none text-slate-400">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                      </div>
                    </div>
                    {errors.parType && <span className="text-red-500 text-xs font-medium">{errors.parType}</span>}
                  </div>

                  {formData.parType && (
                    <div className="flex flex-col gap-1 animate-in slide-in-from-top-2 duration-200">
                      <label className="text-sm font-semibold text-slate-700">Número da Nota do PAR</label>
                      <input
                        type="text"
                        placeholder="Digite o número da nota"
                        className={inputClass(errors.parInvoiceNumber)}
                        value={formData.parInvoiceNumber}
                        onChange={(e) => setFormData({ ...formData, parInvoiceNumber: e.target.value })}
                      />
                      {errors.parInvoiceNumber && <span className="text-red-500 text-xs font-medium">{errors.parInvoiceNumber}</span>}
                    </div>
                  )}
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-sm font-semibold text-slate-700 block mb-1">Observações Adicionais (Opcional)</label>
                  <textarea
                    placeholder="Descreva detalhes adicionais se necessário"
                    className={`${inputClass(errors.parDescription)} h-24 resize-none`}
                    value={formData.parDescription}
                    onChange={(e) => setFormData({ ...formData, parDescription: e.target.value })}
                  />
                </div>
              </div>
            )}
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-lg shadow-md transition-all active:scale-[0.98] flex items-center justify-center gap-2"
          >
            ENVIAR PARA CONFERÊNCIA
          </button>
        </form>
      </div>

      <div className="space-y-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-slate-900 px-6 py-4">
            <h3 className="text-white font-black text-sm uppercase tracking-widest">Meu Log de Eventos</h3>
          </div>
          <div className="p-4 max-h-[600px] overflow-y-auto space-y-4">
            {logs.length === 0 ? (
              <p className="text-slate-400 text-xs font-bold text-center py-8">Nenhum evento registrado hoje.</p>
            ) : (
              logs.map((log) => (
                <div key={log.id} className="border-l-2 border-blue-500 pl-4 py-1 space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black text-blue-600 uppercase tracking-tighter">{log.action}</span>
                    <span className="text-[9px] text-slate-400 font-mono">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 font-medium leading-tight">{log.details}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
