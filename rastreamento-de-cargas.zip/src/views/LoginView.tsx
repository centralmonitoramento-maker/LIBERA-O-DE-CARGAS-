
import React, { useState } from 'react';
import { User } from '../types';

interface LoginViewProps {
  role: 'expedition' | 'central' | 'audit' | 'analysis';
  users: User[];
  onLoginSuccess: (username: string) => void;
  onRegisterRequest: (user: Omit<User, 'id' | 'status' | 'createdAt'>) => void;
}

const ROLE_NAMES = {
  expedition: 'Expedição',
  central: 'Central de Monitoramento',
  audit: 'Auditoria de Gate',
  analysis: 'Análise de Dados',
};

export const LoginView: React.FC<LoginViewProps> = ({ role, users, onLoginSuccess, onRegisterRequest }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [storeLocation, setStoreLocation] = useState('');
  const [jobFunction, setJobFunction] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const normalize = (str: string) => {
    return str.trim().toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (mode === 'login') {
      const normalizedInputUsername = normalize(username);
      
      const user = users.find(u => normalize(u.username) === normalizedInputUsername);
      
      if (user) {
        if (user.password !== password) {
          setError('Senha incorreta.');
          return;
        }

        const hasAccess = user.role === role || user.systemRole === 'administrator';
        if (!hasAccess) {
          setError(`Este usuário (${user.username}) não tem permissão para acessar a etapa ${ROLE_NAMES[role]}.`);
          return;
        }

        if (user.status === 'active') {
          onLoginSuccess(user.username);
        } else if (user.status === 'pending') {
          setError('Seu cadastro ainda está aguardando aprovação da Auditoria.');
        } else {
          setError('Seu cadastro foi rejeitado pela Auditoria.');
        }
      } else {
        setError('Usuário não encontrado para esta etapa.');
      }
    } else {
      // Register request
      const exists = users.find(u => u.username === username && u.role === role);
      if (exists) {
        setError('Este usuário já existe para esta etapa.');
        return;
      }

      onRegisterRequest({
        username,
        password,
        fullName,
        storeLocation,
        jobFunction,
        role,
      });
      setSuccess('Solicitação enviada! Aguarde a aprovação da Auditoria.');
      setMode('login');
      setPassword('');
      setFullName('');
      setStoreLocation('');
      setJobFunction('');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-20 bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden transition-all duration-500">
      <div className="bg-slate-900 p-8 text-center">
        <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
          <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
          </svg>
        </div>
        <h2 className="text-2xl font-black text-white tracking-tight">
          {mode === 'login' ? 'Acesso Restrito' : 'Solicitar Cadastro'}
        </h2>
        <p className="text-slate-400 text-sm font-bold uppercase tracking-widest mt-1">{ROLE_NAMES[role]}</p>
      </div>
      
      <form onSubmit={handleSubmit} className="p-8 space-y-6">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            {error}
          </div>
        )}

        {success && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-600 px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            {success}
          </div>
        )}
        
        {mode === 'register' && (
          <>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider ml-1">Nome Completo</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                placeholder="Digite seu nome completo"
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider ml-1">Loja Locado</label>
              <input
                type="text"
                value={storeLocation}
                onChange={(e) => setStoreLocation(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                placeholder="Ex: Loja 07 SIA"
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider ml-1">Função</label>
              <input
                type="text"
                value={jobFunction}
                onChange={(e) => setJobFunction(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                placeholder="Ex: Conferente de Expedição"
                required
              />
            </div>
          </>
        )}

        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider ml-1">Usuário</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            placeholder="Escolha um nome de usuário"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider ml-1">Senha</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            placeholder="••••••"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black py-4 rounded-xl shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2"
        >
          {mode === 'login' ? 'ENTRAR NO SISTEMA' : 'ENVIAR SOLICITAÇÃO'}
        </button>

        <div className="text-center pt-2">
          <button
            type="button"
            onClick={() => {
              setMode(mode === 'login' ? 'register' : 'login');
              setError('');
              setSuccess('');
            }}
            className="text-[10px] font-black text-blue-600 hover:text-blue-500 uppercase tracking-widest transition-colors"
          >
            {mode === 'login' ? 'Não tem conta? Solicite cadastro' : 'Já tem conta? Faça login'}
          </button>
        </div>
      </form>
      
      <div className="p-4 bg-slate-50 border-t border-slate-100 text-center">
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">CargoRelease Security Protocol v2.5</p>
      </div>
    </div>
  );
};
